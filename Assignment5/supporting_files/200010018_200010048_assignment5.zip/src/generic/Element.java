package generic;

public interface Element {
	
	void handleEvent(Event event);

}
