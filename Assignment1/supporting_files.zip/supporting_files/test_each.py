#!/bin/python

import sys
from evaluate import evaluate

evaluate(sys.argv[1])
